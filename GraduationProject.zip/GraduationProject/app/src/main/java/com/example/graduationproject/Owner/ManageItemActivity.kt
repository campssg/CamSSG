package com.example.graduationproject.Owner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.graduationproject.R

class ManageItemActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_item_main)
    }
}
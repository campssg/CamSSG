package com.example.graduationproject.User

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.graduationproject.R

//HJ 마이페이지-마트 즐겨찾기
class bookmark_martActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_1bookmark_mart)
    }
}
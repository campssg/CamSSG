package com.example.graduationproject.User

data class UserNickRequest(
        val userNickname:String
)
//package com.example.graduationproject.UserSigning
//
//import com.google.gson.annotations.SerializedName
//import retrofit2.http.Body
//
//data class RegisterRequest (
//    @SerializedName("phoneNumber")
//    val phoneNumber: String,
//    @SerializedName("userEmail")
//    val userEmail: String,
//    @SerializedName("userName")
//    val userName: String,
//    @SerializedName("userNickname")
//    val userNickname: String,
//    @SerializedName("userPassword")
//    val userPassword: String,
//    @SerializedName("userRole")
//    val userRole: String=""
//)
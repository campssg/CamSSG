package com.example.graduationproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CompareCartListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_1compare_cart_list)
    }
}
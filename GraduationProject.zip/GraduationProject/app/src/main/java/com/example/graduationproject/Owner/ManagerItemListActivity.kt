package com.example.graduationproject.Owner

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.graduationproject.R

//HJ 마트 상품 관리
class ManagerItemListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_item_list)
    }
}
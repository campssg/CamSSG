package com.example.graduationproject.User

data class UserPassRequest(
        val newPassword:String,
        val recentPassword:String
)
package com.example.graduationproject.UserSigning

data class UserLoginRequest(
    val userEmail:String,
    val userPassword:String
)
